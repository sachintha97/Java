package iit.tutorial1.myapplication;

public class MyApplication {


    public static void main(String[] args) {
        Person obj = new Person("Ben");
        obj.displayName();

        
    }
}

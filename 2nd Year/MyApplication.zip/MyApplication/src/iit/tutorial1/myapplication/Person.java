package iit.tutorial1.myapplication;

public class Person {
    String name;
    String sureName;
    int age;

    public Person(String name1){
        name = name1;

    }

    public void displayName(){
        System.out.println(name);
    }

    public void setSureName(String sureName1){
        sureName = sureName1;
    }

    public void setAge(int age1){
        age = age1;

    }
     public String getSureName(){
        return sureName;
     }

     public int getAge(){
        return age;
     }

}
